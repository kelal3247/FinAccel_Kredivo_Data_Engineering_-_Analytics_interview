import scrapy

class BlibliSpider(scrapy.Spider):
    name = "blibli"
    start_urls = ["https://www.blibli.com/p/under-armour-phenom-novelty-crew-training-socks-kaos-kaki-fitness-wanita-1351764-010/is--UNA-60023-00366-00003"]
    
    def parse(self , response):
            
        product_name = response.xpath('//*[@class="product-name"]/text()').get() #"https://www.blibli.com/p/under-armour-phenom-novelty-crew-training-socks-kaos-kaki-fitness-wanita-1351764-010/is--UNA-60023-00366-00003"
        category = response.xpath('//*[@class="category"]/text()').get()        
        price = response.xpath('//*[@class="product__price-after"]/text()').get() #"https://www.blibli.com/p/under-armour-phenom-novelty-crew-training-socks-kaos-kaki-fitness-wanita-1351764-010/is--UNA-60023-00366-00003"
    
        # return the output
        yield{
            'Product name class': product_name,
            'Category': category,
            'Price class': price         
        }